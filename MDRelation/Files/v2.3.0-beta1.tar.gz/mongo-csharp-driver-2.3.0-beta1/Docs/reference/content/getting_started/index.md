+++
date = "2015-03-17T15:36:56Z"
draft = false
title = "Getting Started"
[menu.main]
  weight = 10
  identifier = "Getting Started"
  pre = "<i class='fa fa-road'></i>"
+++

## Getting Started

To help you get started quickly on the new driver, follow:

- [Installation]({{< relref "getting_started\installation.md" >}})
- [Quick Tour]({{< relref "getting_started\quick_tour.md" >}})
- [Admin Quick Tour]({{< relref "getting_started\admin_quick_tour.md" >}})